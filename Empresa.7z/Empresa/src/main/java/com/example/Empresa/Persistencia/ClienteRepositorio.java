package com.example.Empresa.Persistencia;

import com.example.Empresa.Persistencia.Crud.ClienteCrudRepositorio;
import com.example.Empresa.Persistencia.Entity.Cliente;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public class ClienteRepositorio {

    ClienteCrudRepositorio clienteCrudRepositorio;

    public List<Cliente> ConsultaGeneral(){
        return (List<Cliente>) clienteCrudRepositorio.findAll();
    }

    public Optional<Cliente> consultaIndividual(String ident_cliente){
        return clienteCrudRepositorio.findById(ident_cliente);
    }
    public Cliente Guardar(Cliente cliente){
        return clienteCrudRepositorio.save(cliente);
    }
    public void Eliminar(String ident_cliente){
        clienteCrudRepositorio.deleteById(ident_cliente);
    }


}
