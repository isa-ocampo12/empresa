package com.example.Empresa.Persistencia.Mapeador;

import com.example.Empresa.Dominio.Client;
import com.example.Empresa.Persistencia.Entity.Cliente;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

@Mapper(componentModel = "spring")
public interface ClienteMapeador {

    @Mappings({
            @Mapping(source = "IdentCliente", target = "ClientId"),
            @Mapping(source = "NomCliente", target = "name"),
            @Mapping(source = "DirCliente", target = "address"),
            @Mapping(source = "TelCliente", target = "phone"),
            @Mapping(source = "Activo", target = "active")


    })
    Client toCliente(Cliente cliente);
    @InheritInverseConfiguration
    Cliente toClient (Client client);
}
