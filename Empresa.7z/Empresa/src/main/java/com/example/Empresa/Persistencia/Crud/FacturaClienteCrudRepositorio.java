package com.example.Empresa.Persistencia.Crud;

import com.example.Empresa.Persistencia.FacturaCliente;
import org.springframework.data.repository.CrudRepository;

public interface FacturaClienteCrudRepositorio extends CrudRepository <FacturaCliente, String> {
}
