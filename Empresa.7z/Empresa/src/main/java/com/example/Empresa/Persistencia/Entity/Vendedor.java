package com.example.Empresa.Persistencia.Entity;

import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name = "vendedor")
public class Vendedor {
    @Id
    @Column(name = "ident_vendedor")
    private String IdentCliente;

    @Column(name = "nom_vendedor")
    private String NomVendedor;

    @Column(name = "tel_vendedor")
    private String TelVendedor;

    Boolean activo;

    @OneToMany(mappedBy = "factura_compra")
    private List<FacturaCliente> facturaCliente;

    public String getIdentCliente() {
        return IdentCliente;
    }

    public void setIdentCliente(String identCliente) {
        IdentCliente = identCliente;
    }

    public String getNomVendedor() {
        return NomVendedor;
    }

    public void setNomVendedor(String nomVendedor) {
        NomVendedor = nomVendedor;
    }

    public String getTelVendedor() {
        return TelVendedor;
    }

    public void setTelVendedor(String telVendedor) {
        TelVendedor = telVendedor;
    }

    public Boolean getActivo() {
        return activo;
    }

    public void setActivo(Boolean activo) {
        this.activo = activo;
    }
}
