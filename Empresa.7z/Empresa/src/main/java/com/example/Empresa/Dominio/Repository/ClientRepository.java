package com.example.Empresa.Dominio.Repository;

import com.example.Empresa.Dominio.Client;
import java.util.List;

public interface ClientRepository {
    public List<Client> getAll();
    Client getByClient (String clientId);

    Client save (Client client);
    boolean delete (String clientId);
}
