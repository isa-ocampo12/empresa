package com.example.Empresa.Persistencia;

import com.example.Empresa.Persistencia.Crud.FacturaClienteCrudRepositorio;
import com.example.Empresa.Persistencia.Entity.Cliente;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class FacturaCliente {
    FacturaClienteCrudRepositorio facturaClienteCrudRepositorio;

    public List<FacturaCliente> ConsultaGeneral(){
        return (List<FacturaCliente>) facturaClienteCrudRepositorio.findAll();
    }

    public Optional<FacturaCliente> consultaIndividual(String cod_factura){
        return facturaClienteCrudRepositorio.findById(cod_factura);
    }
    public FacturaCliente Guardar(FacturaCliente facturaCliente){
        return facturaClienteCrudRepositorio.save(facturaCliente);
    }
    public void Eliminar(String cod_factura){

        facturaClienteCrudRepositorio.deleteById(cod_factura);
    }

}
