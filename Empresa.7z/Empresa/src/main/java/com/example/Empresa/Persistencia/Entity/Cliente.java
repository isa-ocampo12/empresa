package com.example.Empresa.Persistencia.Entity;

import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name = "cliente")
public class Cliente {

    @Id
    @Column(name = "ident_cliente")
    String IdentCliente;

    @Column(name = "nom_cliente")
    String NomCliente;

    @Column(name = "dir_cliente")
    String DirCliente;

    @Column(name = "tel_cliente")
    String TelCliente;

    Boolean activo;

    @OneToMany(mappedBy = "factura_compra")
    private List<FacturaCliente> facturaClientes;

    public String getIdentCliente() {
        return IdentCliente;
    }

    public void setIdentCliente(String identCliente) {
        IdentCliente = identCliente;
    }

    public String getNomCliente() {
        return NomCliente;
    }

    public void setNomCliente(String nomCliente) {
        NomCliente = nomCliente;
    }

    public String getDirCliente() {
        return DirCliente;
    }

    public void setDirCliente(String dirCliente) {
        DirCliente = dirCliente;
    }

    public String getTelCliente() {
        return TelCliente;
    }

    public void setTelCliente(String telCliente) {
        TelCliente = telCliente;
    }

    public Boolean getActivo() {
        return activo;
    }

    public void setActivo(Boolean activo) {
        this.activo = activo;
    }
}
