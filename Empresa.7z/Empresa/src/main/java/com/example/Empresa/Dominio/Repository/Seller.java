package com.example.Empresa.Dominio.Repository;

import com.example.Empresa.Dominio.Seller;
import java.util.List;

public interface Seller {
    public List<Seller> getAll();
    Seller getByClient (String sellerId);

    Seller save (Seller seller);
    boolean delete (String sellerId);
}
