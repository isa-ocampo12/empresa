package com.example.Empresa.Persistencia.Entity;

import jakarta.persistence.*;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "factura_compra")
public class FacturaCliente {

    @Id
    @Column(name = "cod_factura")
    private String CodFactura;
    private LocalDateTime fecha;
    @Column(name = "ident_cliente")
    private String IdentCliente;

    @Column(name = "ident_vendedor")
    private String IdentVendedor;

    @Column(name = "activo")
    private Boolean Activo;

    @ManyToOne
    @JoinColumn(name = "ident_cliente", insertable = false, updatable = false)
    private Cliente cliente;

    @JoinColumn(name = "ident_vendedor", insertable = false, updatable = false)
    private Vendedor vendedor;

    @OneToMany(mappedBy = "producto_factura")
    private List<ProductoFactura> productoFactura;

    public String getCodFactura() {
        return CodFactura;
    }

    public void setCodFactura(String codFactura) {
        CodFactura = codFactura;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public void setFecha(LocalDateTime fecha) {
        this.fecha = fecha;
    }

    public String getIdentCliente() {
        return IdentCliente;
    }

    public void setIdentCliente(String identCliente) {
        IdentCliente = identCliente;
    }

    public String getIdentVendedor() {
        return IdentVendedor;
    }

    public void setIdentVendedor(String identVendedor) {
        IdentVendedor = identVendedor;
    }

    public Boolean getActivo() {
        return Activo;
    }

    public void setActivo(Boolean activo) {
        Activo = activo;
    }
}
