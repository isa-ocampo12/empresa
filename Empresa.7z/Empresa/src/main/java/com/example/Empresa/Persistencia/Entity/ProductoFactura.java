package com.example.Empresa.Persistencia.Entity;

import jakarta.persistence.*;

@Entity
@Table(name = "producto_factura")
public class ProductoFactura {

    @EmbeddedId
    private ProdctoFacturaPK Id;

    @Column(name = "val_unitario")
    Float ValUnitario;

    @Column(name = "cantidad")
    Integer cantidad;

    @ManyToOne
    @JoinColumn(name = "cod_factura", insertable = false, updatable = false)
    private FacturaCliente facturaCliente;
    @JoinColumn(name = "cod_producto", insertable = false, updatable = false)
    private Producto producto;

    public ProdctoFacturaPK getId() {
        return Id;
    }

    public void setId(ProdctoFacturaPK id) {
        Id = id;
    }

    public Float getValUnitario() {
        return ValUnitario;
    }

    public void setValUnitario(Float valUnitario) {
        ValUnitario = valUnitario;
    }

    public Integer getCantidad() {
        return cantidad;
    }

    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }
}
