package com.example.Empresa.Dominio;

public class ProductBuy {

}
