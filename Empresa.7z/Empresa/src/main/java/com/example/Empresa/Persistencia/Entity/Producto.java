package com.example.Empresa.Persistencia.Entity;


import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name = "producto")
public class Producto {

    @Id
    @Column(name = "cod_producto")
    private String CodProducto;

    @Column(name = "nom_producto")
    private String NomProducto;

    @Column(name = "existencias")
    private Integer Existencias;

    @Column(name = "valor_actual")
    private Float ValorActual;

    @Column(name = "activo")
    private Boolean Activo;

    @OneToMany(mappedBy = "producto_factura")
    private List<ProductoFactura> productoFactura;

    public String getCodProducto() {
        return CodProducto;
    }

    public void setCodProducto(String codProducto) {
        CodProducto = codProducto;
    }

    public String getNomProducto() {
        return NomProducto;
    }

    public void setNomProducto(String nomProducto) {
        NomProducto = nomProducto;
    }

    public Integer getExistencias() {
        return Existencias;
    }

    public void setExistencias(Integer existencias) {
        Existencias = existencias;
    }

    public Float getValorActual() {
        return ValorActual;
    }

    public void setValorActual(Float valorActual) {
        ValorActual = valorActual;
    }

    public Boolean getActivo() {
        return Activo;
    }

    public void setActivo(Boolean activo) {
        Activo = activo;
    }
}
