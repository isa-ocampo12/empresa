package com.example.Empresa.Persistencia;

import com.example.Empresa.Persistencia.Crud.ProductoCrudRepositorio;
import com.example.Empresa.Persistencia.Entity.Producto;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class ProductoRepositorio {

    ProductoCrudRepositorio productoCrudRepositorio;

    public List<Producto> ConsultaGeneral(){

        return (List<Producto>) productoCrudRepositorio.findAll();
    }

    public Optional<Producto> consultaIndividual(String cod_producto){
        return productoCrudRepositorio.findById(cod_producto);
    }
    public Producto Guardar(Producto producto){
        return productoCrudRepositorio.save(producto);
    }
    public void Eliminar(String cod_producto){
        productoCrudRepositorio.deleteById(cod_producto);
    }
}
