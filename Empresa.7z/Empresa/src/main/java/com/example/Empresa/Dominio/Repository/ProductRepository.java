package com.example.Empresa.Dominio.Repository;

import com.example.Empresa.Dominio.Product;

import java.util.List;

public interface ProductRepository {
    public List<Product> gtAll();
    Product getByProduct (String codeProduct);

    Product save (Product product);
    boolean delete (String codeProduct);
}
